package kr.co.service;

public interface AOPTestService {

	void aoptest();

	void aoptest2();

	void aoptest3();

}
