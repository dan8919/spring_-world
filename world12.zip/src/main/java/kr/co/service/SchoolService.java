package kr.co.service;

public interface SchoolService {

}
