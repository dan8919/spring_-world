/*
 * package kr.co.service;
 * 
 * import kr.co.domain.BoardVO;
 * 
 * public interface TranTestService {
 * 
 * 
 * 
 * void insertNupdate1(BoardVO vo); }
 */

package kr.co.service;

 

import kr.co.domain.BoardVO;

 

public interface TranTestService {

 

	void insertNupdate1(BoardVO vo);

 

}

 