package kr.co.persistence;

public interface SchoolDAO {

}
