package kr.co.persistence;

import java.util.List;

import org.springframework.stereotype.Repository;

import kr.co.domain.DepartDTO;
@Repository
public class DpartDAOImpl implements DpartDAO{

	@Override
	public List<DepartDTO> list() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(DepartDTO dto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public DepartDTO read(String did) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DepartDTO updateui(String did) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(DepartDTO dto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(String did) {
		// TODO Auto-generated method stub
		
	}



}
